module.exports = {
  packages: {
    'ngx-bootstrap': {
      entryPoints: { './dist': { ignore: true, } },
    },
  }
};
