0.0: Use-case name
==================
**Primary Actor**: User

**Scope**: Ngx-bootstrap DEMO / BS version 3&4

**Goal**: Use-case goal

Main success scenario:
----------------------
Main use-case scenario

1.
2.
3.

Extensions:
-----------
Possible variants of actions

4a.

Variations:
-----------
Other way for getting the result

2*.
