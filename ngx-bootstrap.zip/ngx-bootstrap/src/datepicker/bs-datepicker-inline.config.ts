import { Injectable } from '@angular/core';
import { BsDatepickerConfig } from './bs-datepicker.config';

@Injectable({
  providedIn: 'root'
})
export class BsDatepickerInlineConfig extends BsDatepickerConfig { }
