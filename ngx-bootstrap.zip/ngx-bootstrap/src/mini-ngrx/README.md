# mini-ngrx

This library was generated with [Nx](https://nx.dev).

## Running unit tests

Run `nx test mini-ngrx` to execute the unit tests.
